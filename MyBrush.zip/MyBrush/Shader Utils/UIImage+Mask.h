//
//  UIImage+Mask.h
//  MyBrush
//
//  Created by 小明 on 2018/5/24.
//  Copyright © 2018年 laihua. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Mask)

+ (UIImage *)circleMaskWithSize:(NSUInteger)sideLength;

@end
