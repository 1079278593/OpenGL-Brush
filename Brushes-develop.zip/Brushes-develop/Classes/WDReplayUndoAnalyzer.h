//
//  WDReplayUndoAnalyzer.h
//  Brushes
//
//  This Source Code Form is subject to the terms of the Mozilla Public
//  License, v. 2.0. If a copy of the MPL was not distributed with this
//  file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
//  Original implementation by Scott Vachalek
//
//  Copyright (c) 2012-2013 Steve Sprang
//

#import <Foundation/Foundation.h>
#import "WDDocumentChangeVisitor.h"

@interface WDReplayUndoAnalyzer : NSObject

- (NSArray *) changesWithoutUndos;
- (NSSet *) undone;
- (void) visitUndo:(NSData *)undo;
- (void) visitRedo:(NSData *)redo;
- (void) visitClearUndoStack:(NSData *)clear;
- (void) visitOther:(NSData *)change;

@end
